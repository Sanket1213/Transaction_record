-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: May 20, 2020 at 09:41 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mom_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Page_no` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `C_Name` varchar(200) NOT NULL,
  `C_Contact` varchar(200) NOT NULL,
  `Total_Amount` int(11) NOT NULL,
  `Paid_Amount` int(11) NOT NULL,
  `Remaining_Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Page_no`, `date`, `C_Name`, `C_Contact`, `Total_Amount`, `Paid_Amount`, `Remaining_Amount`) VALUES
('1', '', 'Anuradha Dhurat', '98887654432', 700, 200, 500),
('2', '', 'Lata Dhurat', '4444444444', 10000, 400, 9600),
('3', '16/05/20', 'sanket', '9970880388', 100, 50, 50),
('4', '18/05/20', 'pd', '', 500, 200, 300),
('24', '20/05/20', 'sanket', '888888888', 1000, 500, 500),
('333', '20/05/20', 'pd', '7777', 1000, 500, 500),
('111', '20/05/20', 'pk', '246453', 555, 55, 500),
('222', '20/05/20', 'pd', '888', 55, 55, 0),
('99', '20/05/20', 'yo', '468464', 1000, 500, 500),
('88', '20/05/20', 'll', '53453', 200, 100, 100),
('77', '20/05/20', 'bakri', '645644', 200, 100, 100),
('66', '20/05/20', 'lala', '989', 1, 0, 1),
('55', '20/05/20', 'papa', '989', 1, 0, 1),
('44', '20/05/20', 'ka', '5456', 44, 0, 44),
('9879', '20/05/20', 'pp', '', 0, 0, 0),
('987', '20/05/20', 'pp', '', 1000, 0, 1000),
('98777', '20/05/20', 'km', '', 1000, 1000, 0),
('65465', '20/05/20', 'lp', '', 1000, 1000, 0),
('5465', '20/05/20', 'zz', '777777', 500, 200, 300);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
